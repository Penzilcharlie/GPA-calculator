#include <iostream>
#include <iomanip>
#include <stdlib.h>

using namespace std;

int main()
{
    int len;
    float sum = 0;
    float credits = 0;
    float gpa;
    std::string name;

    cout << "--GPA CALCULATOR--" << endl;
    cout << endl;
    cout << "How many courses are you doing this Semester " << endl;
    cout << "Number : ";
    cin >> len;
    cout << endl;
    system("cls");

    std::string course_names[len];
    float credit_hrs[len];
    float scores[len];
    string grade_letter[len];
    int counter=1;

    if (len >1 && len <=7)
    {
      cout << "--PLEASE ENTER YOUR RESPECTIVE COURSE GRADING INFO--" << endl;
      cout << endl;

    for (int i=0; i<len; i++)
        {
        std::cout << "Please enter details of course No." << i << endl;
        std::cout << "Course name: ";
        std::getline(std::cin >> std::ws, course_names[i]);

        cout << "Score: ";
        cin >> scores[i];

        cout << "Credit hours: ";
        cin >> credit_hrs[i];
        cout << endl;

        if (scores[i] <= 100 && scores[i] >= 80)
        {
            scores[i]=4.0*credit_hrs[i];
            grade_letter[i] = "A";
        }

        else if(scores[i] <=79 && scores[i] >=75) {
            scores[i]=3.5*credit_hrs[i];
            grade_letter[i] = "B+";
        }

        else if(scores[i] <=74 && scores[i] >=70) {
            scores[i]=3.0*credit_hrs[i];
            grade_letter[i] = "B";
        }

        else if(scores[i] <=69 && scores[i] >=65) {
            scores[i]=2.5*credit_hrs[i];
            grade_letter[i] = "C+";
        }

        else if(scores[i] <=64 && scores[i] >=60) {
            scores[i]=2.0*credit_hrs[i];
            grade_letter[i] = "C";
        }

        else if(scores[i] <=59 && scores[i] >=55) {
            scores[i]=1.5*credit_hrs[i];
            grade_letter[i] = "D+";
        }

        else if(scores[i] <=54 && scores[i] >=50) {
             scores[i]=1.0*credit_hrs[i];
             grade_letter[i] = "D";
        }

        else if(scores[i] <=50) {
            scores[i]=0.0*credit_hrs[i];
            grade_letter[i] = "E";
        }

        else
        {
          cout << "Input the right score!!  --(0-100)--" << endl;
          cout << "--Enter score again--" << endl;
          cout << endl;
          i = i-1;
        }

            credits = credits + credit_hrs[i];
            sum = sum + scores[i];
            counter++;
        }

        system("cls");

       {
         cout << "--YOUR RESULTS FOR THIS SEMESTER--"<<endl;
         gpa = sum / credits;
         cout << endl;
         cout << "_______________________________________________________"<< endl;
         cout << endl;
         for (int a=0; a < len; a++)
        {
         cout << "\t" << course_names[a] << "\t\t | \t" << grade_letter[a] << "\t |\t" << setprecision(1) << fixed << scores[a]<< endl;
        }
         cout << endl;
         cout << "_______________________________________________________"<< endl;

         cout << endl << "Score grade point: " << sum <<endl;
         cout << "Sum of credit hours: " << credits <<endl;
         cout << endl;
         cout << "-- Your GPA = "<< setprecision(4) << fixed << gpa << " --" <<endl;
        }

    }


    return 0;

}
